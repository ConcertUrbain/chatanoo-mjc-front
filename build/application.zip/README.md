# chatanoo-mjc-front

Social web-apps for MJC (Maison des Jeunes et de la Culture).

Each app connects to : 
<ul>
<li>chatanoo JSON API</li>
<li>chatanoo MediaCenter</li>
</ul>

It can be seen here (for Nogent-sur-Marne) :
http://www.chatanoo.org/mjc/front/nogent/

Uses javascript Librairies : BackboneJS/UnderscoreJS, JQuery, MediaElementJS, KineticJS, Greensock.
